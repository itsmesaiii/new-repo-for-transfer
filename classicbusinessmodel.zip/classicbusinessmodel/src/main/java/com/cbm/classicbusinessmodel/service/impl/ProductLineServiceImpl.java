package com.cbm.classicbusinessmodel.service.impl;

import com.cbm.classicbusinessmodel.dto.ProductLineResponseDTO;
import com.cbm.classicbusinessmodel.entity.ProductLine;
import com.cbm.classicbusinessmodel.exception.ResourceNotFoundException;
import com.cbm.classicbusinessmodel.mapper.ProductLineMapper;
import com.cbm.classicbusinessmodel.repository.ProductLineRepository;
import com.cbm.classicbusinessmodel.service.ProductLineService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class ProductLineServiceImpl implements ProductLineService {

    private final ProductLineRepository productLineRepository;
    private final ProductLineMapper productLineMapper;

    public ProductLineServiceImpl(ProductLineRepository productLineRepository, ProductLineMapper productLineMapper) {
        this.productLineRepository = productLineRepository;
        this.productLineMapper = productLineMapper;
    }

    @Override
    public List<ProductLineResponseDTO> getAllProductLines() {
        return productLineRepository.findAll().stream()
                .map(productLineMapper::toProductLineResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ProductLineResponseDTO getProductLineById(String productLineId) {
        ProductLine productLine = productLineRepository.findById(productLineId)
                .orElseThrow(() -> new ResourceNotFoundException("ProductLine not found with id: " + productLineId));
        return productLineMapper.toProductLineResponseDTO(productLine);
    }
}