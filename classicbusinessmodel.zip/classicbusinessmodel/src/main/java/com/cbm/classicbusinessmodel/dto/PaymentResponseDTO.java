package com.cbm.classicbusinessmodel.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class PaymentResponseDTO {

    private Integer customerNumber;
    private String checkNumber;
    private LocalDate paymentDate;
    private BigDecimal amount;
}