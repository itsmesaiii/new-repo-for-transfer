package com.cbm.classicbusinessmodel.service.impl;

import com.cbm.classicbusinessmodel.dto.PaymentResponseDTO;
import com.cbm.classicbusinessmodel.mapper.PaymentMapper;
import com.cbm.classicbusinessmodel.repository.PaymentRepository;
import com.cbm.classicbusinessmodel.service.PaymentService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;
    private final PaymentMapper paymentMapper;

    public PaymentServiceImpl(PaymentRepository paymentRepository, PaymentMapper paymentMapper) {
        this.paymentRepository = paymentRepository;
        this.paymentMapper = paymentMapper;
    }

    @Override
    public List<PaymentResponseDTO> getAllPayments() {
        return paymentRepository.findAll().stream()
                .map(paymentMapper::toPaymentResponseDTO)
                .collect(Collectors.toList());
    }
}