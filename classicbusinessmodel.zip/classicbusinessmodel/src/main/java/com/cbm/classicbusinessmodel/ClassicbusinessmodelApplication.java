package com.cbm.classicbusinessmodel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassicbusinessmodelApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClassicbusinessmodelApplication.class, args);
	}

}
