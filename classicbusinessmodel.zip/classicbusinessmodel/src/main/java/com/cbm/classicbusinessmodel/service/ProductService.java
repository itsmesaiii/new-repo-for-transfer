package com.cbm.classicbusinessmodel.service;

import com.cbm.classicbusinessmodel.dto.ProductResponseDTO;
import java.math.BigDecimal;
import java.util.List;

public interface ProductService {
    List<ProductResponseDTO> getAllProducts();
    ProductResponseDTO getProductById(String productId);
    void updateProductName(String productCode, String newName);
    void updateProductLine(String productCode, String productLine);
    void updateProductScale(String productCode, String scale);
    void updateProductVendor(String productCode, String vendor);
    void updateProductDescription(String productCode, String description);
    void updateQuantityInStock(String productCode, Short quantity);
    void updateBuyPrice(String productCode, BigDecimal price);
    void updateMsrp(String productCode, BigDecimal msrp);
}