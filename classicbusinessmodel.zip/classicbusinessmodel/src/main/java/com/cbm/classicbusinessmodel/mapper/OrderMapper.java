package com.cbm.classicbusinessmodel.mapper;

import com.cbm.classicbusinessmodel.dto.OrderDetailDTO;
import com.cbm.classicbusinessmodel.dto.OrderResponseDTO;
import com.cbm.classicbusinessmodel.entity.Order;
import com.cbm.classicbusinessmodel.entity.OrderDetail;
import org.springframework.stereotype.Component;
import java.util.stream.Collectors;

@Component
public class OrderMapper {

    public OrderResponseDTO toOrderResponseDTO(Order order) {
        if (order == null) {
            return null;
        }
        OrderResponseDTO dto = new OrderResponseDTO();
        dto.setOrderNumber(order.getId());
        dto.setOrderDate(order.getOrderDate());
        dto.setRequiredDate(order.getRequiredDate());
        dto.setShippedDate(order.getShippedDate());
        dto.setStatus(order.getStatus());
        dto.setComments(order.getComments());

        if (order.getCustomer() != null) {
            dto.setCustomerNumber(order.getCustomer().getId());
        }
        if (order.getOrderdetails() != null) {
            dto.setOrderDetails(order.getOrderdetails().stream()
                    .map(this::toOrderDetailDTO)
                    .collect(Collectors.toList()));
        }
        return dto;
    }

    private OrderDetailDTO toOrderDetailDTO(OrderDetail orderDetail) {
        if (orderDetail == null) {
            return null;
        }
        OrderDetailDTO dto = new OrderDetailDTO();
        dto.setOrderLineNumber(orderDetail.getOrderLineNumber());
        dto.setPriceEach(orderDetail.getPriceEach());
        dto.setQuantityOrdered(orderDetail.getQuantityOrdered());
        if (orderDetail.getProduct() != null) {
            dto.setProductCode(orderDetail.getProduct().getId());
        }
        return dto;
    }
}