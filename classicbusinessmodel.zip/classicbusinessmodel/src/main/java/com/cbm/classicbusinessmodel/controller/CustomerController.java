package com.cbm.classicbusinessmodel.controller;

import com.cbm.classicbusinessmodel.dto.CustomerRequestDTO;
import com.cbm.classicbusinessmodel.dto.CustomerResponseDTO;
import com.cbm.classicbusinessmodel.dto.SuccessResponseDTO;
import com.cbm.classicbusinessmodel.service.CustomerService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/v1/customer")
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    private ResponseEntity<SuccessResponseDTO> createSuccessResponse(String message) {
        return ResponseEntity.ok(new SuccessResponseDTO(ZonedDateTime.now(), message));
    }

    // GET Endpoints
    @GetMapping("/all")
    public ResponseEntity<List<CustomerResponseDTO>> getAllCustomers() {
        return ResponseEntity.ok(customerService.getAllCustomers());
    }

    @GetMapping("/id/{id}")
    public ResponseEntity<CustomerResponseDTO> getCustomerById(@PathVariable Integer id) {
        return ResponseEntity.ok(customerService.getCustomerById(id));
    }

    @GetMapping("/name/{name}")
    public ResponseEntity<CustomerResponseDTO> getCustomerByName(@PathVariable String name) {
        return ResponseEntity.ok(customerService.getCustomerByName(name));
    }

    // POST Endpoint
    @PostMapping("/add")
    public ResponseEntity<CustomerResponseDTO> createCustomer(@Valid @RequestBody CustomerRequestDTO customerRequestDTO) {
        CustomerResponseDTO createdCustomer = customerService.createCustomer(customerRequestDTO);
        return new ResponseEntity<>(createdCustomer, HttpStatus.CREATED);
    }

    // DELETE Endpoint
    @DeleteMapping("/{id}")
    public ResponseEntity<SuccessResponseDTO> deleteCustomerById(@PathVariable Integer id) {
        customerService.deleteCustomerById(id);
        return createSuccessResponse("Customer deleted successfully");
    }

    // PUT Endpoints
    @PutMapping("/name/{id}/{newName}")
    public ResponseEntity<SuccessResponseDTO> updateCustomerName(@PathVariable Integer id, @PathVariable String newName) {
        customerService.updateCustomerName(id, newName);
        return createSuccessResponse("Customer name updated successfully");
    }

    @PutMapping("/contact/firstname/{id}/{firstName}")
    public ResponseEntity<SuccessResponseDTO> updateContactFirstName(@PathVariable Integer id, @PathVariable String firstName) {
        customerService.updateContactFirstName(id, firstName);
        return createSuccessResponse("Contact first name updated successfully");
    }

    @PutMapping("/contact/lastname/{id}/{lastName}")
    public ResponseEntity<SuccessResponseDTO> updateContactLastName(@PathVariable Integer id, @PathVariable String lastName) {
        customerService.updateContactLastName(id, lastName);
        return createSuccessResponse("Contact last name updated successfully");
    }

    @PutMapping("/phone/{id}/{phone}")
    public ResponseEntity<SuccessResponseDTO> updatePhone(@PathVariable Integer id, @PathVariable String phone) {
        customerService.updatePhone(id, phone);
        return createSuccessResponse("Phone number updated successfully");
    }

    @PutMapping("/address/line1/{id}/{line1}")
    public ResponseEntity<SuccessResponseDTO> updateAddressLine1(@PathVariable Integer id, @PathVariable String line1) {
        customerService.updateAddressLine1(id, line1);
        return createSuccessResponse("Address line 1 updated successfully");
    }

    @PutMapping("/address/line2/{id}/{line2}")
    public ResponseEntity<SuccessResponseDTO> updateAddressLine2(@PathVariable Integer id, @PathVariable String line2) {
        customerService.updateAddressLine2(id, line2);
        return createSuccessResponse("Address line 2 updated successfully");
    }

    @PutMapping("/address/city/{id}/{city}")
    public ResponseEntity<SuccessResponseDTO> updateCity(@PathVariable Integer id, @PathVariable String city) {
        customerService.updateCity(id, city);
        return createSuccessResponse("City updated successfully");
    }

    @PutMapping("/address/state/{id}/{state}")
    public ResponseEntity<SuccessResponseDTO> updateState(@PathVariable Integer id, @PathVariable String state) {
        customerService.updateState(id, state);
        return createSuccessResponse("State updated successfully");
    }

    @PutMapping("/address/postalcode/{id}/{postalCode}")
    public ResponseEntity<SuccessResponseDTO> updatePostalCode(@PathVariable Integer id, @PathVariable String postalCode) {
        customerService.updatePostalCode(id, postalCode);
        return createSuccessResponse("Postal code updated successfully");
    }

    @PutMapping("/address/country/{id}/{country}")
    public ResponseEntity<SuccessResponseDTO> updateCountry(@PathVariable Integer id, @PathVariable String country) {
        customerService.updateCountry(id, country);
        return createSuccessResponse("Country updated successfully");
    }

    @PutMapping("/salesrep/{id}/{employeeId}")
    public ResponseEntity<SuccessResponseDTO> updateSalesRep(@PathVariable Integer id, @PathVariable Integer employeeId) {
        customerService.updateSalesRep(id, employeeId);
        return createSuccessResponse("Sales representative updated successfully");
    }

    @PutMapping("/creditlimit/{id}/{limit}")
    public ResponseEntity<SuccessResponseDTO> updateCreditLimit(@PathVariable Integer id, @PathVariable BigDecimal limit) {
        customerService.updateCreditLimit(id, limit);
        return createSuccessResponse("Credit limit updated successfully");
    }
}