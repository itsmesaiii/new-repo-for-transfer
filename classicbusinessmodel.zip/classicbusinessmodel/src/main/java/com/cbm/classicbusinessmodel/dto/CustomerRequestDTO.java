package com.cbm.classicbusinessmodel.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class CustomerRequestDTO {

    @NotNull(message = "Customer number is required")
    private Integer customerNumber;

    @NotBlank(message = "Customer name is required")
    private String customerName;

    @NotBlank(message = "Contact last name is required")
    private String contactLastName;

    @NotBlank(message = "Contact first name is required")
    private String contactFirstName;

    @NotBlank(message = "Phone number is required")
    private String phone;

    @Valid
    @NotNull(message = "Address is required")
    private AddressDTO address;

    private Integer salesRepEmployeeNumber;
    private BigDecimal creditLimit;
}