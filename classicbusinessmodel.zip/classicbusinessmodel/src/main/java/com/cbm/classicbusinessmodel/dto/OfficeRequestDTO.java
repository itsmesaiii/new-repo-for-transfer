package com.cbm.classicbusinessmodel.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class OfficeRequestDTO {

    @NotBlank(message = "Office code is required")
    private String officeCode;

    @NotBlank(message = "Phone number is required")
    private String phone;

    @NotBlank(message = "Territory is required")
    private String territory;

    @Valid
    @NotNull(message = "Address is required")
    private AddressDTO address;
}