package com.cbm.classicbusinessmodel.service.impl;

import com.cbm.classicbusinessmodel.dto.ProductResponseDTO;
import com.cbm.classicbusinessmodel.entity.Product;
import com.cbm.classicbusinessmodel.entity.ProductLine;
import com.cbm.classicbusinessmodel.exception.ResourceNotFoundException;
import com.cbm.classicbusinessmodel.mapper.ProductMapper;
import com.cbm.classicbusinessmodel.repository.ProductRepository;
import com.cbm.classicbusinessmodel.repository.ProductLineRepository;
import com.cbm.classicbusinessmodel.service.ProductService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final ProductLineRepository productLineRepository;
    private final ProductMapper productMapper;

    public ProductServiceImpl(ProductRepository productRepository, ProductLineRepository productLineRepository, ProductMapper productMapper) {
        this.productRepository = productRepository;
        this.productLineRepository = productLineRepository;
        this.productMapper = productMapper;
    }

    private Product findProductById(String productId) {
        return productRepository.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + productId));
    }

    @Override
    public List<ProductResponseDTO> getAllProducts() {
        return productRepository.findAll().stream()
                .map(productMapper::toProductResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ProductResponseDTO getProductById(String productId) {
        return productMapper.toProductResponseDTO(findProductById(productId));
    }

    @Override
    public void updateProductName(String productCode, String newName) {
        Product product = findProductById(productCode);
        product.setProductName(newName);
        productRepository.save(product);
    }

    @Override
    public void updateProductLine(String productCode, String productLineId) {
        Product product = findProductById(productCode);
        ProductLine productLine = productLineRepository.findById(productLineId)
                .orElseThrow(() -> new ResourceNotFoundException("ProductLine not found with id: " + productLineId));
        product.setProductLine(productLine);
        productRepository.save(product);
    }

    @Override
    public void updateProductScale(String productCode, String scale) {
        Product product = findProductById(productCode);
        product.setProductScale(scale);
        productRepository.save(product);
    }

    @Override
    public void updateProductVendor(String productCode, String vendor) {
        Product product = findProductById(productCode);
        product.setProductVendor(vendor);
        productRepository.save(product);
    }

    @Override
    public void updateProductDescription(String productCode, String description) {
        Product product = findProductById(productCode);
        product.setProductDescription(description);
        productRepository.save(product);
    }

    @Override
    public void updateQuantityInStock(String productCode, Short quantity) {
        Product product = findProductById(productCode);
        product.setQuantityInStock(quantity);
        productRepository.save(product);
    }

    @Override
    public void updateBuyPrice(String productCode, BigDecimal price) {
        Product product = findProductById(productCode);
        product.getPricing().setBuyPrice(price);
        productRepository.save(product);
    }

    @Override
    public void updateMsrp(String productCode, BigDecimal msrp) {
        Product product = findProductById(productCode);
        product.getPricing().setMsrp(msrp);
        productRepository.save(product);
    }
}