package com.cbm.classicbusinessmodel.dto;

import lombok.Data;

@Data
public class ProductLineResponseDTO {

    private String productLine;
    private String textDescription;
    private String htmlDescription;
    private String image;
}