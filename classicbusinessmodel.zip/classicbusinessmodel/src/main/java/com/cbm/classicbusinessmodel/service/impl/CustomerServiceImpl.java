package com.cbm.classicbusinessmodel.service.impl;

import com.cbm.classicbusinessmodel.dto.CustomerRequestDTO;
import com.cbm.classicbusinessmodel.dto.CustomerResponseDTO;
import com.cbm.classicbusinessmodel.entity.Customer;
import com.cbm.classicbusinessmodel.entity.Employee;
import com.cbm.classicbusinessmodel.entity.embeddable.Address;
import com.cbm.classicbusinessmodel.entity.embeddable.Contact;
import com.cbm.classicbusinessmodel.exception.ResourceNotFoundException;
import com.cbm.classicbusinessmodel.mapper.CustomerMapper;
import com.cbm.classicbusinessmodel.repository.CustomerRepository;
import com.cbm.classicbusinessmodel.repository.EmployeeRepository;
import com.cbm.classicbusinessmodel.service.CustomerService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;
    private final EmployeeRepository employeeRepository;
    private final CustomerMapper customerMapper;

    public CustomerServiceImpl(CustomerRepository customerRepository, EmployeeRepository employeeRepository, CustomerMapper customerMapper) {
        this.customerRepository = customerRepository;
        this.employeeRepository = employeeRepository;
        this.customerMapper = customerMapper;
    }

    private Customer findCustomerById(Integer customerId) {
        return customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id: " + customerId));
    }

    @Override
    public List<CustomerResponseDTO> getAllCustomers() {
        return customerRepository.findAll().stream()
                .map(customerMapper::toCustomerResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public CustomerResponseDTO getCustomerById(Integer customerId) {
        return customerMapper.toCustomerResponseDTO(findCustomerById(customerId));
    }

    @Override
    public CustomerResponseDTO getCustomerByName(String customerName) {
        Customer customer = customerRepository.findByCustomerName(customerName)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with name: " + customerName));
        return customerMapper.toCustomerResponseDTO(customer);
    }

    @Override
    public CustomerResponseDTO createCustomer(CustomerRequestDTO dto) {
        Customer customer = new Customer();
        customer.setId(dto.getCustomerNumber());
        customer.setCustomerName(dto.getCustomerName());
        customer.setPhone(dto.getPhone());
        customer.setCreditLimit(dto.getCreditLimit());

        Contact contact = new Contact();
        contact.setFirstName(dto.getContactFirstName());
        contact.setLastName(dto.getContactLastName());
        customer.setContact(contact);

        Address address = new Address();
        address.setAddressLine1(dto.getAddress().getAddressLine1());
        address.setAddressLine2(dto.getAddress().getAddressLine2());
        address.setCity(dto.getAddress().getCity());
        address.setState(dto.getAddress().getState());
        address.setPostalCode(dto.getAddress().getPostalCode());
        address.setCountry(dto.getAddress().getCountry());
        customer.setAddress(address);

        if (dto.getSalesRepEmployeeNumber() != null) {
            Employee salesRep = employeeRepository.findById(dto.getSalesRepEmployeeNumber())
                    .orElseThrow(() -> new ResourceNotFoundException("Sales Rep Employee not found with id: " + dto.getSalesRepEmployeeNumber()));
            customer.setSalesRep(salesRep);
        }

        Customer savedCustomer = customerRepository.save(customer);
        return customerMapper.toCustomerResponseDTO(savedCustomer);
    }

    @Override
    public void deleteCustomerById(Integer customerId) {
        if (!customerRepository.existsById(customerId)) {
            throw new ResourceNotFoundException("Customer not found with id: " + customerId);
        }
        customerRepository.deleteById(customerId);
    }

    @Override
    public void updateCustomerName(Integer customerId, String newName) {
        Customer customer = findCustomerById(customerId);
        customer.setCustomerName(newName);
        customerRepository.save(customer);
    }

    @Override
    public void updateContactFirstName(Integer customerId, String newFirstName) {
        Customer customer = findCustomerById(customerId);
        customer.getContact().setFirstName(newFirstName);
        customerRepository.save(customer);
    }

    @Override
    public void updateContactLastName(Integer customerId, String newLastName) {
        Customer customer = findCustomerById(customerId);
        customer.getContact().setLastName(newLastName);
        customerRepository.save(customer);
    }

    @Override
    public void updatePhone(Integer customerId, String newPhone) {
        Customer customer = findCustomerById(customerId);
        customer.setPhone(newPhone);
        customerRepository.save(customer);
    }

    @Override
    public void updateAddressLine1(Integer customerId, String addressLine1) {
        Customer customer = findCustomerById(customerId);
        customer.getAddress().setAddressLine1(addressLine1);
        customerRepository.save(customer);
    }

    @Override
    public void updateAddressLine2(Integer customerId, String addressLine2) {
        Customer customer = findCustomerById(customerId);
        customer.getAddress().setAddressLine2(addressLine2);
        customerRepository.save(customer);
    }

    @Override
    public void updateCity(Integer customerId, String city) {
        Customer customer = findCustomerById(customerId);
        customer.getAddress().setCity(city);
        customerRepository.save(customer);
    }

    @Override
    public void updateState(Integer customerId, String state) {
        Customer customer = findCustomerById(customerId);
        customer.getAddress().setState(state);
        customerRepository.save(customer);
    }

    @Override
    public void updatePostalCode(Integer customerId, String postalCode) {
        Customer customer = findCustomerById(customerId);
        customer.getAddress().setPostalCode(postalCode);
        customerRepository.save(customer);
    }

    @Override
    public void updateCountry(Integer customerId, String country) {
        Customer customer = findCustomerById(customerId);
        customer.getAddress().setCountry(country);
        customerRepository.save(customer);
    }

    @Override
    public void updateSalesRep(Integer customerId, Integer employeeId) {
        Customer customer = findCustomerById(customerId);
        Employee salesRep = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Sales Rep Employee not found with id: " + employeeId));
        customer.setSalesRep(salesRep);
        customerRepository.save(customer);
    }

    @Override
    public void updateCreditLimit(Integer customerId, BigDecimal creditLimit) {
        Customer customer = findCustomerById(customerId);
        customer.setCreditLimit(creditLimit);
        customerRepository.save(customer);
    }
}