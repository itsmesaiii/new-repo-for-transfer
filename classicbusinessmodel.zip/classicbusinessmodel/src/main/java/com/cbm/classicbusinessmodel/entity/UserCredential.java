package com.cbm.classicbusinessmodel.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "user_credentials")
public class UserCredential {

    @Id
    @Column(name = "username", length = 50)
    private String username;

    @Column(name = "password", nullable = false)
    private String password;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "employeeNumber", nullable = false, unique = true)
    private Employee employee;
}