package com.cbm.classicbusinessmodel.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class OrderDetailDTO {

    private String productCode;
    private Integer quantityOrdered;
    private BigDecimal priceEach;
    private Short orderLineNumber;
}