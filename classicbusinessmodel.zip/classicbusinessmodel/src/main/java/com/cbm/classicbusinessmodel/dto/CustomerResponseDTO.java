package com.cbm.classicbusinessmodel.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class CustomerResponseDTO {

    private Integer customerNumber;
    private String customerName;
    private String contactLastName;
    private String contactFirstName;
    private String phone;
    private AddressDTO address;
    private Integer salesRepEmployeeNumber;
    private BigDecimal creditLimit;
}