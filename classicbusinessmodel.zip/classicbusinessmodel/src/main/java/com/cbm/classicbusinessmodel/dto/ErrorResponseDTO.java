package com.cbm.classicbusinessmodel.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZonedDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ErrorResponseDTO {

    private ZonedDateTime timestamp;
    private int status;
    private String message;
    private String path;
}