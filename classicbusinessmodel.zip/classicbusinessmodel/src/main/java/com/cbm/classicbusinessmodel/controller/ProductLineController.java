package com.cbm.classicbusinessmodel.controller;

import com.cbm.classicbusinessmodel.dto.ProductLineResponseDTO;
import com.cbm.classicbusinessmodel.service.ProductLineService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@RequestMapping("/api/v1/productline")
public class ProductLineController {

    private final ProductLineService productLineService;

    public ProductLineController(ProductLineService productLineService) {
        this.productLineService = productLineService;
    }

    @GetMapping("/all")
    public ResponseEntity<List<ProductLineResponseDTO>> getAllProductLines() {
        return ResponseEntity.ok(productLineService.getAllProductLines());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductLineResponseDTO> getProductLineById(@PathVariable String id) {
        return ResponseEntity.ok(productLineService.getProductLineById(id));
    }
}