package com.cbm.classicbusinessmodel.repository;

import com.cbm.classicbusinessmodel.entity.Office;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OfficeRepository extends JpaRepository<Office, String> {

    List<Office> findByAddressCityIn(List<String> cities);
}