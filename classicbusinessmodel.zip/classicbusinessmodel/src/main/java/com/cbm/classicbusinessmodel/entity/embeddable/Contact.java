package com.cbm.classicbusinessmodel.entity.embeddable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class Contact {

    @Column(name = "contactLastName", nullable = false, length = 50)
    private String lastName;

    @Column(name = "contactFirstName", nullable = false, length = 50)
    private String firstName;
}