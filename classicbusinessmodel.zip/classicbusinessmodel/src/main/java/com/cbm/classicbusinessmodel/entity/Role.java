package com.cbm.classicbusinessmodel.entity;

public enum Role {
    Admin,
    Non_Admin
}