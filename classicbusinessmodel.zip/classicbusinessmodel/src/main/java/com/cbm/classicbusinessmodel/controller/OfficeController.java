package com.cbm.classicbusinessmodel.controller;

import com.cbm.classicbusinessmodel.dto.OfficeRequestDTO;
import com.cbm.classicbusinessmodel.dto.OfficeResponseDTO;
import com.cbm.classicbusinessmodel.dto.SuccessResponseDTO;
import com.cbm.classicbusinessmodel.service.OfficeService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.ZonedDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/v1/office")
public class OfficeController {

    private final OfficeService officeService;

    public OfficeController(OfficeService officeService) {
        this.officeService = officeService;
    }

    private ResponseEntity<SuccessResponseDTO> createSuccessResponse(String message) {
        return ResponseEntity.ok(new SuccessResponseDTO(ZonedDateTime.now(), message));
    }

    // GET Endpoints
    @GetMapping("/all")
    public ResponseEntity<List<OfficeResponseDTO>> getAllOffices() {
        return ResponseEntity.ok(officeService.getAllOffices());
    }

    @GetMapping("/{officeCode}")
    public ResponseEntity<OfficeResponseDTO> getOfficeByCode(@PathVariable String officeCode) {
        return ResponseEntity.ok(officeService.getOfficeByCode(officeCode));
    }

    @GetMapping("/cities/{cities}")
    public ResponseEntity<List<OfficeResponseDTO>> getOfficesByCities(@PathVariable List<String> cities) {
        return ResponseEntity.ok(officeService.getOfficesByCities(cities));
    }

    // POST Endpoint
    @PostMapping("/add")
    public ResponseEntity<OfficeResponseDTO> createOffice(@Valid @RequestBody OfficeRequestDTO officeRequestDTO) {
        OfficeResponseDTO createdOffice = officeService.createOffice(officeRequestDTO);
        return new ResponseEntity<>(createdOffice, HttpStatus.CREATED);
    }

    // PUT Endpoints
    @PutMapping("/{officeCode}/{phoneNumber}")
    public ResponseEntity<SuccessResponseDTO> updateOfficePhoneNumber(@PathVariable String officeCode, @PathVariable String phoneNumber) {
        officeService.updateOfficePhoneNumber(officeCode, phoneNumber);
        return createSuccessResponse("Office phone number updated successfully");
    }

    @PutMapping("/update/{officeCode}")
    public ResponseEntity<OfficeResponseDTO> updateOffice(@PathVariable String officeCode, @Valid @RequestBody OfficeRequestDTO officeRequestDTO) {
        OfficeResponseDTO updatedOffice = officeService.updateOffice(officeCode, officeRequestDTO);
        return ResponseEntity.ok(updatedOffice);
    }

    // DELETE Endpoint
    @DeleteMapping("/{officeCode}")
    public ResponseEntity<SuccessResponseDTO> deleteOffice(@PathVariable String officeCode) {
        officeService.deleteOffice(officeCode);
        return createSuccessResponse("Office deleted successfully");
    }
}