package com.cbm.classicbusinessmodel.dto;

import com.cbm.classicbusinessmodel.entity.Role;
import lombok.Data;

@Data
public class EmployeeResponseDTO {

    private Integer employeeNumber;
    private String lastName;
    private String firstName;
    private String extension;
    private String email;
    private String officeCode;
    private Integer reportsToId;
    private String jobTitle;
    private Role role;
}