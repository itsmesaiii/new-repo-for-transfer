package com.cbm.classicbusinessmodel.service;

import com.cbm.classicbusinessmodel.dto.ProductLineResponseDTO;
import java.util.List;

public interface ProductLineService {
    List<ProductLineResponseDTO> getAllProductLines();
    ProductLineResponseDTO getProductLineById(String productLineId);
}