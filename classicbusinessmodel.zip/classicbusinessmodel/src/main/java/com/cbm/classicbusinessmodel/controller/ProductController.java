package com.cbm.classicbusinessmodel.controller;

import com.cbm.classicbusinessmodel.dto.ProductResponseDTO;
import com.cbm.classicbusinessmodel.dto.SuccessResponseDTO;
import com.cbm.classicbusinessmodel.service.ProductService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/v1/product")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    private ResponseEntity<SuccessResponseDTO> createSuccessResponse(String message) {
        return ResponseEntity.ok(new SuccessResponseDTO(ZonedDateTime.now(), message));
    }

    // GET Endpoints
    @GetMapping("/all")
    public ResponseEntity<List<ProductResponseDTO>> getAllProducts() {
        return ResponseEntity.ok(productService.getAllProducts());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductResponseDTO> getProductById(@PathVariable String id) {
        return ResponseEntity.ok(productService.getProductById(id));
    }

    // PUT Endpoints
    @PutMapping("/name/{productCode}/{productName}")
    public ResponseEntity<SuccessResponseDTO> updateProductName(@PathVariable String productCode, @PathVariable String productName) {
        productService.updateProductName(productCode, productName);
        return createSuccessResponse("Product name updated successfully");
    }

    @PutMapping("/line/{productCode}/{productLine}")
    public ResponseEntity<SuccessResponseDTO> updateProductLine(@PathVariable String productCode, @PathVariable String productLine) {
        productService.updateProductLine(productCode, productLine);
        return createSuccessResponse("Product line updated successfully");
    }

    @PutMapping("/scale/{productCode}/{productScale}")
    public ResponseEntity<SuccessResponseDTO> updateProductScale(@PathVariable String productCode, @PathVariable String productScale) {
        productService.updateProductScale(productCode, productScale);
        return createSuccessResponse("Product scale updated successfully");
    }

    @PutMapping("/vendor/{productCode}/{productVendor}")
    public ResponseEntity<SuccessResponseDTO> updateProductVendor(@PathVariable String productCode, @PathVariable String productVendor) {
        productService.updateProductVendor(productCode, productVendor);
        return createSuccessResponse("Product vendor updated successfully");
    }

    @PutMapping("/description/{productCode}")
    public ResponseEntity<SuccessResponseDTO> updateProductDescription(@PathVariable String productCode, @RequestBody String description) {
        productService.updateProductDescription(productCode, description);
        return createSuccessResponse("Product description updated successfully");
    }

    @PutMapping("/quantity/{productCode}/{quantity}")
    public ResponseEntity<SuccessResponseDTO> updateQuantityInStock(@PathVariable String productCode, @PathVariable Short quantity) {
        productService.updateQuantityInStock(productCode, quantity);
        return createSuccessResponse("Quantity in stock updated successfully");
    }

    @PutMapping("/buyprice/{productCode}/{price}")
    public ResponseEntity<SuccessResponseDTO> updateBuyPrice(@PathVariable String productCode, @PathVariable BigDecimal price) {
        productService.updateBuyPrice(productCode, price);
        return createSuccessResponse("Buy price updated successfully");
    }

    @PutMapping("/msrp/{productCode}/{msrp}")
    public ResponseEntity<SuccessResponseDTO> updateMsrp(@PathVariable String productCode, @PathVariable BigDecimal msrp) {
        productService.updateMsrp(productCode, msrp);
        return createSuccessResponse("MSRP updated successfully");
    }
}