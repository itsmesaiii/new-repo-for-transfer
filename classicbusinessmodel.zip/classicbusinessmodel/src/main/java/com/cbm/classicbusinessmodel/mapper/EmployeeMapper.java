package com.cbm.classicbusinessmodel.mapper;

import com.cbm.classicbusinessmodel.dto.EmployeeResponseDTO;
import com.cbm.classicbusinessmodel.entity.Employee;
import org.springframework.stereotype.Component;

@Component
public class EmployeeMapper {

    public EmployeeResponseDTO toEmployeeResponseDTO(Employee employee) {
        if (employee == null) {
            return null;
        }
        EmployeeResponseDTO dto = new EmployeeResponseDTO();
        dto.setEmployeeNumber(employee.getId());
        dto.setLastName(employee.getLastName());
        dto.setFirstName(employee.getFirstName());
        dto.setExtension(employee.getExtension());
        dto.setEmail(employee.getEmail());
        dto.setJobTitle(employee.getJobTitle());
        dto.setRole(employee.getRole());

        if (employee.getOffice() != null) {
            dto.setOfficeCode(employee.getOffice().getId());
        }
        if (employee.getReportsTo() != null) {
            dto.setReportsToId(employee.getReportsTo().getId());
        }

        return dto;
    }
}