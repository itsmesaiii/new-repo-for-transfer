package com.cbm.classicbusinessmodel.entity;

import com.cbm.classicbusinessmodel.entity.embeddable.Address;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.LinkedHashSet;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "offices")
public class Office {
    @Id
    @Column(name = "officeCode", nullable = false, length = 10)
    private String id;

    @Embedded
    private Address address;

    @Column(name = "phone", nullable = false, length = 50)
    private String phone;

    @Column(name = "territory", nullable = false, length = 10)
    private String territory;

    @OneToMany(mappedBy = "office")
    private Set<Employee> employees = new LinkedHashSet<>();
}