package com.cbm.classicbusinessmodel.mapper;

import com.cbm.classicbusinessmodel.dto.ProductLineResponseDTO;
import com.cbm.classicbusinessmodel.entity.ProductLine;
import org.springframework.stereotype.Component;

@Component
public class ProductLineMapper {

    public ProductLineResponseDTO toProductLineResponseDTO(ProductLine productLine) {
        if (productLine == null) {
            return null;
        }
        ProductLineResponseDTO dto = new ProductLineResponseDTO();
        dto.setProductLine(productLine.getId());
        dto.setTextDescription(productLine.getTextDescription());
        dto.setHtmlDescription(productLine.getHtmlDescription());
        dto.setImage(productLine.getImage());
        return dto;
    }
}