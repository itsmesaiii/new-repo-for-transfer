package com.cbm.classicbusinessmodel.service.impl;

import com.cbm.classicbusinessmodel.dto.OrderResponseDTO;
import com.cbm.classicbusinessmodel.entity.Order;
import com.cbm.classicbusinessmodel.exception.ResourceNotFoundException;
import com.cbm.classicbusinessmodel.mapper.OrderMapper;
import com.cbm.classicbusinessmodel.repository.OrderRepository;
import com.cbm.classicbusinessmodel.service.OrderService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final OrderMapper orderMapper;

    public OrderServiceImpl(OrderRepository orderRepository, OrderMapper orderMapper) {
        this.orderRepository = orderRepository;
        this.orderMapper = orderMapper;
    }

    @Override
    public List<OrderResponseDTO> getAllOrders() {
        return orderRepository.findAll().stream()
                .map(orderMapper::toOrderResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public OrderResponseDTO getOrderById(Integer orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + orderId));
        return orderMapper.toOrderResponseDTO(order);
    }
}