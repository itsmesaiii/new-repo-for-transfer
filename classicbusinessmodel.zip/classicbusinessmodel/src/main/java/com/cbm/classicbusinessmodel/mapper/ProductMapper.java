package com.cbm.classicbusinessmodel.mapper;

import com.cbm.classicbusinessmodel.dto.ProductResponseDTO;
import com.cbm.classicbusinessmodel.entity.Product;
import org.springframework.stereotype.Component;

@Component
public class ProductMapper {

    public ProductResponseDTO toProductResponseDTO(Product product) {
        if (product == null) {
            return null;
        }
        ProductResponseDTO dto = new ProductResponseDTO();
        dto.setProductCode(product.getId());
        dto.setProductName(product.getProductName());
        dto.setProductScale(product.getProductScale());
        dto.setProductVendor(product.getProductVendor());
        dto.setProductDescription(product.getProductDescription());
        dto.setQuantityInStock(product.getQuantityInStock());

        if (product.getProductLine() != null) {
            dto.setProductLine(product.getProductLine().getId());
        }
        if (product.getPricing() != null) {
            dto.setBuyPrice(product.getPricing().getBuyPrice());
            dto.setMsrp(product.getPricing().getMsrp());
        }
        return dto;
    }
}