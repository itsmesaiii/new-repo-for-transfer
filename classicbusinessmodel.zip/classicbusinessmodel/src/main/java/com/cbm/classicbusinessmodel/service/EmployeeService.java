package com.cbm.classicbusinessmodel.service;

import com.cbm.classicbusinessmodel.dto.EmployeeRequestDTO;
import com.cbm.classicbusinessmodel.dto.EmployeeResponseDTO;
import java.util.List;

public interface EmployeeService {
    List<EmployeeResponseDTO> getAllEmployees();
    EmployeeResponseDTO getEmployeeById(Integer employeeId);
    EmployeeResponseDTO getEmployeeByEmail(String email);
    EmployeeResponseDTO createEmployee(EmployeeRequestDTO employeeRequestDTO);
    void deleteEmployeeById(Integer employeeId);
    void updateLastName(Integer employeeId, String lastName);
    void updateFirstName(Integer employeeId, String firstName);
    void updateExtension(Integer employeeId, String extension);
    void updateEmail(Integer employeeId, String email);
    void updateOffice(Integer employeeId, String officeCode);
    void updateReportsTo(Integer employeeId, Integer managerId);
    void updateJobTitle(Integer employeeId, String jobTitle);
}