package com.cbm.classicbusinessmodel.service.impl;

import com.cbm.classicbusinessmodel.dto.OfficeRequestDTO;
import com.cbm.classicbusinessmodel.dto.OfficeResponseDTO;
import com.cbm.classicbusinessmodel.entity.Office;
import com.cbm.classicbusinessmodel.entity.embeddable.Address;
import com.cbm.classicbusinessmodel.exception.ResourceNotFoundException;
import com.cbm.classicbusinessmodel.mapper.OfficeMapper;
import com.cbm.classicbusinessmodel.repository.OfficeRepository;
import com.cbm.classicbusinessmodel.service.OfficeService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class OfficeServiceImpl implements OfficeService {

    private final OfficeRepository officeRepository;
    private final OfficeMapper officeMapper;

    public OfficeServiceImpl(OfficeRepository officeRepository, OfficeMapper officeMapper) {
        this.officeRepository = officeRepository;
        this.officeMapper = officeMapper;
    }

    private Office findOfficeById(String officeCode) {
        return officeRepository.findById(officeCode)
                .orElseThrow(() -> new ResourceNotFoundException("Office not found with code: " + officeCode));
    }

    @Override
    public List<OfficeResponseDTO> getAllOffices() {
        return officeRepository.findAll().stream()
                .map(officeMapper::toOfficeResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public OfficeResponseDTO getOfficeByCode(String officeCode) {
        return officeMapper.toOfficeResponseDTO(findOfficeById(officeCode));
    }

    @Override
    public List<OfficeResponseDTO> getOfficesByCities(List<String> cities) {
        return officeRepository.findByAddressCityIn(cities).stream()
                .map(officeMapper::toOfficeResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public OfficeResponseDTO createOffice(OfficeRequestDTO dto) {
        Office office = new Office();
        office.setId(dto.getOfficeCode());
        office.setPhone(dto.getPhone());
        office.setTerritory(dto.getTerritory());
        Address address = new Address();
        address.setAddressLine1(dto.getAddress().getAddressLine1());
        address.setAddressLine2(dto.getAddress().getAddressLine2());
        address.setCity(dto.getAddress().getCity());
        address.setState(dto.getAddress().getState());
        address.setPostalCode(dto.getAddress().getPostalCode());
        address.setCountry(dto.getAddress().getCountry());
        office.setAddress(address);
        Office savedOffice = officeRepository.save(office);
        return officeMapper.toOfficeResponseDTO(savedOffice);
    }

    @Override
    public void deleteOffice(String officeCode) {
        if (!officeRepository.existsById(officeCode)) {
            throw new ResourceNotFoundException("Office not found with code: " + officeCode);
        }
        officeRepository.deleteById(officeCode);
    }

    @Override
    public void updateOfficePhoneNumber(String officeCode, String newPhoneNumber) {
        Office office = findOfficeById(officeCode);
        office.setPhone(newPhoneNumber);
        officeRepository.save(office);
    }

    @Override
    public OfficeResponseDTO updateOffice(String officeCode, OfficeRequestDTO dto) {
        Office office = findOfficeById(officeCode);
        office.setPhone(dto.getPhone());
        office.setTerritory(dto.getTerritory());
        office.getAddress().setAddressLine1(dto.getAddress().getAddressLine1());
        office.getAddress().setAddressLine2(dto.getAddress().getAddressLine2());
        office.getAddress().setCity(dto.getAddress().getCity());
        office.getAddress().setState(dto.getAddress().getState());
        office.getAddress().setPostalCode(dto.getAddress().getPostalCode());
        office.getAddress().setCountry(dto.getAddress().getCountry());
        Office updatedOffice = officeRepository.save(office);
        return officeMapper.toOfficeResponseDTO(updatedOffice);
    }
}