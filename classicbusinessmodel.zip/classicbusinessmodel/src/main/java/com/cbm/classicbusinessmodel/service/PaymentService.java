package com.cbm.classicbusinessmodel.service;

import com.cbm.classicbusinessmodel.dto.PaymentResponseDTO;
import java.util.List;

public interface PaymentService {
    List<PaymentResponseDTO> getAllPayments();
}