package com.cbm.classicbusinessmodel.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class ProductResponseDTO {

    private String productCode;
    private String productName;
    private String productLine;
    private String productScale;
    private String productVendor;
    private String productDescription;
    private Short quantityInStock;
    private BigDecimal buyPrice;
    private BigDecimal msrp;
}