package com.cbm.classicbusinessmodel.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "productlines")
public class ProductLine {
    @Id
    @Column(name = "productLine", nullable = false, length = 50)
    private String id;

    @Column(name = "textDescription", length = 4000)
    private String textDescription;

    @Lob
    // This is the fix: explicitly define the column type to match the SQL script
    @Column(name = "htmlDescription", columnDefinition = "mediumtext")
    private String htmlDescription;

    @Column(name = "image", length = 2048)
    private String image;
}