package com.cbm.classicbusinessmodel.mapper;

import com.cbm.classicbusinessmodel.dto.AddressDTO;
import com.cbm.classicbusinessmodel.dto.CustomerResponseDTO;
import com.cbm.classicbusinessmodel.entity.Customer;
import com.cbm.classicbusinessmodel.entity.embeddable.Address;
import org.springframework.stereotype.Component;

@Component
public class CustomerMapper {

    public CustomerResponseDTO toCustomerResponseDTO(Customer customer) {
        if (customer == null) {
            return null;
        }

        CustomerResponseDTO dto = new CustomerResponseDTO();
        dto.setCustomerNumber(customer.getId());
        dto.setCustomerName(customer.getCustomerName());
        dto.setPhone(customer.getPhone());
        dto.setCreditLimit(customer.getCreditLimit());

        if (customer.getContact() != null) {
            dto.setContactLastName(customer.getContact().getLastName());
            dto.setContactFirstName(customer.getContact().getFirstName());
        }
        if (customer.getAddress() != null) {
            dto.setAddress(toAddressDTO(customer.getAddress()));
        }
        if (customer.getSalesRep() != null) {
            dto.setSalesRepEmployeeNumber(customer.getSalesRep().getId());
        }

        return dto;
    }

    private AddressDTO toAddressDTO(Address address) {
        if (address == null) {
            return null;
        }
        AddressDTO dto = new AddressDTO();
        dto.setAddressLine1(address.getAddressLine1());
        dto.setAddressLine2(address.getAddressLine2());
        dto.setCity(address.getCity());
        dto.setState(address.getState());
        dto.setPostalCode(address.getPostalCode());
        dto.setCountry(address.getCountry());
        return dto;
    }
}