package com.cbm.classicbusinessmodel.service.impl;

import com.cbm.classicbusinessmodel.dto.EmployeeRequestDTO;
import com.cbm.classicbusinessmodel.dto.EmployeeResponseDTO;
import com.cbm.classicbusinessmodel.entity.Employee;
import com.cbm.classicbusinessmodel.entity.Office;
import com.cbm.classicbusinessmodel.exception.ResourceNotFoundException;
import com.cbm.classicbusinessmodel.mapper.EmployeeMapper;
import com.cbm.classicbusinessmodel.repository.EmployeeRepository;
import com.cbm.classicbusinessmodel.repository.OfficeRepository;
import com.cbm.classicbusinessmodel.service.EmployeeService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final OfficeRepository officeRepository;
    private final EmployeeMapper employeeMapper;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository, OfficeRepository officeRepository, EmployeeMapper employeeMapper) {
        this.employeeRepository = employeeRepository;
        this.officeRepository = officeRepository;
        this.employeeMapper = employeeMapper;
    }

    private Employee findEmployeeById(Integer employeeId) {
        return employeeRepository.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + employeeId));
    }

    @Override
    public List<EmployeeResponseDTO> getAllEmployees() {
        return employeeRepository.findAll().stream()
                .map(employeeMapper::toEmployeeResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public EmployeeResponseDTO getEmployeeById(Integer employeeId) {
        return employeeMapper.toEmployeeResponseDTO(findEmployeeById(employeeId));
    }

    @Override
    public EmployeeResponseDTO getEmployeeByEmail(String email) {
        Employee employee = employeeRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with email: " + email));
        return employeeMapper.toEmployeeResponseDTO(employee);
    }

    @Override
    public EmployeeResponseDTO createEmployee(EmployeeRequestDTO dto) {
        Employee employee = new Employee();
        employee.setId(dto.getEmployeeNumber());
        employee.setLastName(dto.getLastName());
        employee.setFirstName(dto.getFirstName());
        employee.setExtension(dto.getExtension());
        employee.setEmail(dto.getEmail());
        employee.setJobTitle(dto.getJobTitle());
        employee.setRole(dto.getRole());

        Office office = officeRepository.findById(dto.getOfficeCode())
                .orElseThrow(() -> new ResourceNotFoundException("Office not found with code: " + dto.getOfficeCode()));
        employee.setOffice(office);

        if (dto.getReportsToId() != null) {
            Employee manager = findEmployeeById(dto.getReportsToId());
            employee.setReportsTo(manager);
        }

        Employee savedEmployee = employeeRepository.save(employee);
        return employeeMapper.toEmployeeResponseDTO(savedEmployee);
    }

    @Override
    public void deleteEmployeeById(Integer employeeId) {
        if (!employeeRepository.existsById(employeeId)) {
            throw new ResourceNotFoundException("Employee not found with id: " + employeeId);
        }
        employeeRepository.deleteById(employeeId);
    }

    @Override
    public void updateLastName(Integer employeeId, String lastName) {
        Employee employee = findEmployeeById(employeeId);
        employee.setLastName(lastName);
        employeeRepository.save(employee);
    }

    @Override
    public void updateFirstName(Integer employeeId, String firstName) {
        Employee employee = findEmployeeById(employeeId);
        employee.setFirstName(firstName);
        employeeRepository.save(employee);
    }

    @Override
    public void updateExtension(Integer employeeId, String extension) {
        Employee employee = findEmployeeById(employeeId);
        employee.setExtension(extension);
        employeeRepository.save(employee);
    }

    @Override
    public void updateEmail(Integer employeeId, String email) {
        Employee employee = findEmployeeById(employeeId);
        employee.setEmail(email);
        employeeRepository.save(employee);
    }

    @Override
    public void updateOffice(Integer employeeId, String officeCode) {
        Employee employee = findEmployeeById(employeeId);
        Office office = officeRepository.findById(officeCode)
                .orElseThrow(() -> new ResourceNotFoundException("Office not found with code: " + officeCode));
        employee.setOffice(office);
        employeeRepository.save(employee);
    }

    @Override
    public void updateReportsTo(Integer employeeId, Integer managerId) {
        Employee employee = findEmployeeById(employeeId);
        Employee manager = findEmployeeById(managerId);
        employee.setReportsTo(manager);
        employeeRepository.save(employee);
    }

    @Override
    public void updateJobTitle(Integer employeeId, String jobTitle) {
        Employee employee = findEmployeeById(employeeId);
        employee.setJobTitle(jobTitle);
        employeeRepository.save(employee);
    }
}