package com.cbm.classicbusinessmodel.mapper;

import com.cbm.classicbusinessmodel.dto.AddressDTO;
import com.cbm.classicbusinessmodel.dto.OfficeResponseDTO;
import com.cbm.classicbusinessmodel.entity.Office;
import com.cbm.classicbusinessmodel.entity.embeddable.Address;
import org.springframework.stereotype.Component;

@Component
public class OfficeMapper {

    public OfficeResponseDTO toOfficeResponseDTO(Office office) {
        if (office == null) {
            return null;
        }
        OfficeResponseDTO dto = new OfficeResponseDTO();
        dto.setOfficeCode(office.getId());
        dto.setPhone(office.getPhone());
        dto.setTerritory(office.getTerritory());
        dto.setAddress(toAddressDTO(office.getAddress()));
        return dto;
    }

    private AddressDTO toAddressDTO(Address address) {
        if (address == null) {
            return null;
        }
        AddressDTO dto = new AddressDTO();
        dto.setAddressLine1(address.getAddressLine1());
        dto.setAddressLine2(address.getAddressLine2());
        dto.setCity(address.getCity());
        dto.setState(address.getState());
        dto.setPostalCode(address.getPostalCode());
        dto.setCountry(address.getCountry());
        return dto;
    }
}