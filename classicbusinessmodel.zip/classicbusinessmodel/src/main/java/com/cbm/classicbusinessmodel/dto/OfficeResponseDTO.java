package com.cbm.classicbusinessmodel.dto;

import lombok.Data;

@Data
public class OfficeResponseDTO {

    private String officeCode;
    private String phone;
    private String territory;
    private AddressDTO address;
}