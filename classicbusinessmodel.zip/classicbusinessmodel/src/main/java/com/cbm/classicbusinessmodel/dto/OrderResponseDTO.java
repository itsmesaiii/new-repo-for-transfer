package com.cbm.classicbusinessmodel.dto;

import lombok.Data;
import java.time.LocalDate;
import java.util.List;

@Data
public class OrderResponseDTO {

    private Integer orderNumber;
    private LocalDate orderDate;
    private LocalDate requiredDate;
    private LocalDate shippedDate;
    private String status;
    private String comments;
    private Integer customerNumber;
    private List<OrderDetailDTO> orderDetails;
}