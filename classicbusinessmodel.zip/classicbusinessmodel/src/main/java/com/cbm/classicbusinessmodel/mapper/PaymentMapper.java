package com.cbm.classicbusinessmodel.mapper;

import com.cbm.classicbusinessmodel.dto.PaymentResponseDTO;
import com.cbm.classicbusinessmodel.entity.Payment;
import org.springframework.stereotype.Component;

@Component
public class PaymentMapper {

    public PaymentResponseDTO toPaymentResponseDTO(Payment payment) {
        if (payment == null) {
            return null;
        }
        PaymentResponseDTO dto = new PaymentResponseDTO();
        dto.setAmount(payment.getAmount());
        dto.setPaymentDate(payment.getPaymentDate());

        if (payment.getId() != null) {
            dto.setCheckNumber(payment.getId().getCheckNumber());
        }
        if (payment.getCustomer() != null) {
            dto.setCustomerNumber(payment.getCustomer().getId());
        }
        return dto;
    }
}