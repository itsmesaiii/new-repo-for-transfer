package com.cbm.classicbusinessmodel.service;

import com.cbm.classicbusinessmodel.dto.CustomerRequestDTO;
import com.cbm.classicbusinessmodel.dto.CustomerResponseDTO;
import java.math.BigDecimal;
import java.util.List;

public interface CustomerService {
    List<CustomerResponseDTO> getAllCustomers();
    CustomerResponseDTO getCustomerById(Integer customerId);
    CustomerResponseDTO getCustomerByName(String customerName);
    CustomerResponseDTO createCustomer(CustomerRequestDTO customerRequestDTO);
    void deleteCustomerById(Integer customerId);
    void updateCustomerName(Integer customerId, String newName);
    void updateContactFirstName(Integer customerId, String newFirstName);
    void updateContactLastName(Integer customerId, String newLastName);
    void updatePhone(Integer customerId, String newPhone);
    void updateAddressLine1(Integer customerId, String addressLine1);
    void updateAddressLine2(Integer customerId, String addressLine2);
    void updateCity(Integer customerId, String city);
    void updateState(Integer customerId, String state);
    void updatePostalCode(Integer customerId, String postalCode);
    void updateCountry(Integer customerId, String country);
    void updateSalesRep(Integer customerId, Integer employeeId);
    void updateCreditLimit(Integer customerId, BigDecimal creditLimit);
}