package com.cbm.classicbusinessmodel.service;

import com.cbm.classicbusinessmodel.dto.OfficeRequestDTO;
import com.cbm.classicbusinessmodel.dto.OfficeResponseDTO;
import java.util.List;

public interface OfficeService {
    List<OfficeResponseDTO> getAllOffices();
    OfficeResponseDTO getOfficeByCode(String officeCode);
    List<OfficeResponseDTO> getOfficesByCities(List<String> cities);
    OfficeResponseDTO createOffice(OfficeRequestDTO officeRequestDTO);
    void deleteOffice(String officeCode);
    void updateOfficePhoneNumber(String officeCode, String newPhoneNumber);
    OfficeResponseDTO updateOffice(String officeCode, OfficeRequestDTO officeRequestDTO);
}