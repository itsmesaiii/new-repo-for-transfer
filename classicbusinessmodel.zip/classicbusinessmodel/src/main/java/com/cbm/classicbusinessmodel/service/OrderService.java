package com.cbm.classicbusinessmodel.service;

import com.cbm.classicbusinessmodel.dto.OrderResponseDTO;
import java.util.List;

public interface OrderService {
    List<OrderResponseDTO> getAllOrders();
    OrderResponseDTO getOrderById(Integer orderId);
}