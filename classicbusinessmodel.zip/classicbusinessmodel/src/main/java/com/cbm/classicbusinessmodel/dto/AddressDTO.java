package com.cbm.classicbusinessmodel.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class AddressDTO {

    @NotBlank(message = "Address line 1 is required")
    private String addressLine1;
    private String addressLine2;

    @NotBlank(message = "City is required")
    private String city;
    private String state;

    @NotBlank(message = "Postal code is required")
    private String postalCode;

    @NotBlank(message = "Country is required")
    private String country;
}