package com.cbm.classicbusinessmodel.controller;

import com.cbm.classicbusinessmodel.dto.EmployeeRequestDTO;
import com.cbm.classicbusinessmodel.dto.EmployeeResponseDTO;
import com.cbm.classicbusinessmodel.dto.SuccessResponseDTO;
import com.cbm.classicbusinessmodel.service.EmployeeService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.ZonedDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/v1/employee")
public class EmployeeController {

    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    private ResponseEntity<SuccessResponseDTO> createSuccessResponse(String message) {
        return ResponseEntity.ok(new SuccessResponseDTO(ZonedDateTime.now(), message));
    }

    // GET Endpoints
    @GetMapping("/all")
    public ResponseEntity<List<EmployeeResponseDTO>> getAllEmployees() {
        return ResponseEntity.ok(employeeService.getAllEmployees());
    }

    @GetMapping("/id/{id}")
    public ResponseEntity<EmployeeResponseDTO> getEmployeeById(@PathVariable Integer id) {
        return ResponseEntity.ok(employeeService.getEmployeeById(id));
    }

    @GetMapping("/email/{email}")
    public ResponseEntity<EmployeeResponseDTO> getEmployeeByEmail(@PathVariable String email) {
        return ResponseEntity.ok(employeeService.getEmployeeByEmail(email));
    }

    // POST Endpoint
    @PostMapping("/add")
    public ResponseEntity<EmployeeResponseDTO> createEmployee(@Valid @RequestBody EmployeeRequestDTO employeeRequestDTO) {
        EmployeeResponseDTO createdEmployee = employeeService.createEmployee(employeeRequestDTO);
        return new ResponseEntity<>(createdEmployee, HttpStatus.CREATED);
    }

    // DELETE Endpoint
    @DeleteMapping("/{id}")
    public ResponseEntity<SuccessResponseDTO> deleteEmployee(@PathVariable Integer id) {
        employeeService.deleteEmployeeById(id);
        return createSuccessResponse("Employee deleted successfully");
    }

    // PUT Endpoints
    @PutMapping("/lastname/{id}/{lastName}")
    public ResponseEntity<SuccessResponseDTO> updateLastName(@PathVariable Integer id, @PathVariable String lastName) {
        employeeService.updateLastName(id, lastName);
        return createSuccessResponse("Last name updated successfully");
    }

    @PutMapping("/firstname/{id}/{firstName}")
    public ResponseEntity<SuccessResponseDTO> updateFirstName(@PathVariable Integer id, @PathVariable String firstName) {
        employeeService.updateFirstName(id, firstName);
        return createSuccessResponse("First name updated successfully");
    }

    @PutMapping("/extension/{id}/{extension}")
    public ResponseEntity<SuccessResponseDTO> updateExtension(@PathVariable Integer id, @PathVariable String extension) {
        employeeService.updateExtension(id, extension);
        return createSuccessResponse("Extension updated successfully");
    }

    @PutMapping("/email/{id}/{email}")
    public ResponseEntity<SuccessResponseDTO> updateEmail(@PathVariable Integer id, @PathVariable String email) {
        employeeService.updateEmail(id, email);
        return createSuccessResponse("Email updated successfully");
    }

    @PutMapping("/office/{id}/{officeCode}")
    public ResponseEntity<SuccessResponseDTO> updateOffice(@PathVariable Integer id, @PathVariable String officeCode) {
        employeeService.updateOffice(id, officeCode);
        return createSuccessResponse("Office code updated successfully");
    }

    @PutMapping("/reportsto/{id}/{managerId}")
    public ResponseEntity<SuccessResponseDTO> updateReportsTo(@PathVariable Integer id, @PathVariable Integer managerId) {
        employeeService.updateReportsTo(id, managerId);
        return createSuccessResponse("ReportsTo (manager) updated successfully");
    }

    @PutMapping("/jobtitle/{id}/{jobTitle}")
    public ResponseEntity<SuccessResponseDTO> updateJobTitle(@PathVariable Integer id, @PathVariable String jobTitle) {
        employeeService.updateJobTitle(id, jobTitle);
        return createSuccessResponse("Job title updated successfully");
    }
}