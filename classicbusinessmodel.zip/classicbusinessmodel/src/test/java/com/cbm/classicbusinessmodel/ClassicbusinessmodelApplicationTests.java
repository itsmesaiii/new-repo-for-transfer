package com.cbm.classicbusinessmodel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassicbusinessmodelApplicationTests {

	@Test
	void contextLoads() {
	}

}
